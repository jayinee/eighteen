# practice_hackathon
A practice hackathon session from Oct. 21st - Oct. 23rd 2016 for Modern Developer Course with David Gierman and Brian Hernandez building 4 UI elements.
